#include "config.h"


#include <cmocka.h>
#include <cmocka_private.h>

static void test_assert_true_fail(void **state)
{
    int x = 10;

    (void)state; /* unused */
    assert_true(x != 10);
}

int main(void)
{
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_assert_true_fail),
    };

    return cmocka_run_group_tests(tests, NULL, NULL);
}
